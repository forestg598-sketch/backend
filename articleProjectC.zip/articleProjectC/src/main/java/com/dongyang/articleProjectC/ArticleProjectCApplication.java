package com.dongyang.articleProjectC;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ArticleProjectCApplication {

	public static void main(String[] args) {
		SpringApplication.run(ArticleProjectCApplication.class, args);
	}

}
