package com.dongyang.articleProjectC.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class MainController {
    @GetMapping("/")
    public String home(){
        return "index";
    }

    @GetMapping("/intro")
    public String in(){
        return "intro";
    }

}
