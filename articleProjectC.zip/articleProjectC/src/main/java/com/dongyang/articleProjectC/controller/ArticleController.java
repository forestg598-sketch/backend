package com.dongyang.articleProjectC.controller;

import com.dongyang.articleProjectC.dto.ArticleDTO;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class ArticleController {

    @GetMapping("/article/new")
    public String newArticleForm(){
        return "articles/new";
    }

    @PostMapping("/article/new")
    public String newArticleForm(ArticleDTO dto){

        return "";
    }
}



