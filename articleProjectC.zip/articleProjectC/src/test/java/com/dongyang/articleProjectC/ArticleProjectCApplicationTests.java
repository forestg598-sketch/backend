package com.dongyang.articleProjectC;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ArticleProjectCApplicationTests {

	@Test
	void contextLoads() {
	}

}
