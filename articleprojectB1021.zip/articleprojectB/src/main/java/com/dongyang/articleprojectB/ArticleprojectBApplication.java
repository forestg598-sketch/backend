package com.dongyang.articleprojectB;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ArticleprojectBApplication {

	public static void main(String[] args) {
		SpringApplication.run(ArticleprojectBApplication.class, args);
	}

}
