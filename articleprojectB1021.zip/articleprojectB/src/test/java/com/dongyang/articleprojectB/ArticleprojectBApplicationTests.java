package com.dongyang.articleprojectB;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ArticleprojectBApplicationTests {

	@Test
	void contextLoads() {
	}

}
